var searchData=
[
  ['nfcreader_176',['NfcReader',['../reader_8h.html#acfc2a4d6b645d463ba518b602473bf40',1,'reader.h']]]
];
