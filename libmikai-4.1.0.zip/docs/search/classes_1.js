var searchData=
[
  ['nfcreader_99',['NfcReader',['../structNfcReader.html',1,'']]]
];
