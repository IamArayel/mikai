var searchData=
[
  ['reader_171',['reader',['../structSrix.html#a77f4b5aec3ab95c9fd31dd829b66b47d',1,'Srix']]]
];
