var searchData=
[
  ['libnfc_5freader_165',['libnfc_reader',['../structNfcReader.html#a849d466b14b514535a79a0acba0ee792',1,'NfcReader']]],
  ['libnfc_5freaders_166',['libnfc_readers',['../structNfcReader.html#aedb03aad651913e889f1f467e0ba0842',1,'NfcReader']]],
  ['lockable_167',['lockable',['../structSrix.html#a18d8a0b1db828c37f200c2d8cda4895b',1,'Srix']]]
];
