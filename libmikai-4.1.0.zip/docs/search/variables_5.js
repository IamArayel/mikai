var searchData=
[
  ['memory_168',['memory',['../structSrixFlag.html#a938a3b4010509372a7ff924f574583e0',1,'SrixFlag']]],
  ['message_169',['message',['../structMikaiError.html#a4ab6bdd661c4459f4bb90aae4fb0bf27',1,'MikaiError']]]
];
